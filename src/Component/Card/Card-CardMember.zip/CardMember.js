import React from "react";
import { Container, Row, Dropdown } from "react-bootstrap";
import styled from "styled-components";
import more from "../logo/more_horiz.svg";
import CardNewMember from "../Card/CardNewMember";
import More from "../logo/more_horiz_black_24dp.svg";

const Containerstyle = styled.div`
.card{
  height: 313px;
  width: 261px;
  border-radius: 4px;
  box-sizing: border-box;

}

.infomation{
  padding: 16px;
}

.img{
  height: 72px;
  width: 72px;
  border-radius: 50%;
  background-color: #000;
  margin: 0 auto;
}

.name{
  color: #424242;
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  margin-top: 8px;
  text-align: center;
}

.tag{
  color: #282828;
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-size: 32px;
  line-height: 38px;
  margin-top: 4px;
  text-align: center;
}

.role{
  color: #424242;
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  letter-spacing: 0.25px;
  margin-top: 16px;
}

.position{
  background-color: #424242;
  color: #fff;
  position: absolute;
  bottom: 0px;
  width: 100%;
  height: 25px;
  text-align: center;
}

.morebutton{
  position: absolute;
  top: 16px;
  right: 16px;
}

.col-3{
  padding: 0px;
}

.row{
  margin: 0px;
}
.cardNew{
  height: 161px;
  width: 261px;
  border-radius: 4px;
  box-sizing: border-box;

}

.infomation1{
  padding: 16px;
}

.img1{
  height: 72px;
  width: 72px;
  border-radius: 50%;
  background-color: #000;
  margin: 0 auto;
}

.name1{
  color: #424242;
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  margin-top: 8px;
  text-align: center;
}

.tag1{
  color: #282828;
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-size: 32px;
  line-height: 38px;
  margin-top: 4px;
  text-align: center;
}

.role1{
  color: #424242;
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  letter-spacing: 0.25px;
  margin-top: 16px;
}

.position1{
  background-color: #424242;
  color: #fff;
  position: absolute;
  bottom: 0px;
  width: 100%;
  height: 25px;
  text-align: center;
}

.morebutton1{
  position: absolute;
  top: 16px;
  right: 16px;
}

.col-3{
  padding: 0px;
}

.newmember1{
    position: absolute;
    top: -3px;
    left: -2px;
}
span{
  padding: 0px ;
  margin; 0px ;
  float: right;
}
.dropdown-toggle::after {
  visibility: hidden;
}
img {
  float: right;
}
.dropdown-menu{
  min-width:80px;
}
.dropdown-box {
  width: 24px;
  height: 24px;
  float: right;
}
`;

function CardMember() {
  return (
    <Containerstyle>
      <Container fluid="lg" style={{ maxWidth: "1140px" }} className="pt-4 ">
        <Row>
          <div className="card col-3 ">
            <div className="infomation">
              <div className="img"></div>
              <div className="name">Wiwatakon pookpoon</div>
              <div className="tag">Front-end</div>
              <div className="role">
                สร้างเว็บตามที่ UI สร้าง โดยใช้ HTML, CSS, Vue
              </div>
              <Dropdown className="morebutton" align="end">
                <Dropdown.Toggle
                  id="dropdown"
                  className="dropdown-box"
                  as="span"
                >
                  <img src={More} alt="More" />
                  <Dropdown.Menu style={{ width: "80px" }}>
                    <Dropdown.Item
                      eventKey="1"
                      // onClick={() => handleEditTag(elem.id)}
                    >
                      แก้ไข
                    </Dropdown.Item>
                    <Dropdown.Item
                      eventKey="2"
                      // onClick={() => handleEditTag(elem.id)}
                    >
                      แก้ไข
                    </Dropdown.Item>
                    <Dropdown.Item eventKey="2" style={{ color: "red" }}>
                      ลบ
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown.Toggle>
              </Dropdown>
            </div>

            <div className="position">Member</div>
          </div>

          <div className="card col-3 ms-4">
            <div className="infomation">
              <div className="img"></div>
              <div className="name">Wiwatakon pookpoon</div>
              <div className="tag">Front-end</div>
              <div className="role">
                สร้างเว็บตามที่ UI สร้าง โดยใช้ HTML, CSS, Vue
              </div>
              <Dropdown className="morebutton" align="end">
                <Dropdown.Toggle id="dropdown" as="span">
                  <img src={More} alt="More" />
                  <Dropdown.Menu style={{ width: "80px" }}>
                    <Dropdown.Item
                      eventKey="1"
                      // onClick={() => handleEditTag(elem.id)}
                    >
                      แก้ไข
                    </Dropdown.Item>
                    <Dropdown.Item eventKey="2" style={{ color: "red" }}>
                      ลบ
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown.Toggle>
              </Dropdown>
            </div>

            <div className="position">Member</div>
          </div>

          <div className="card col-3 ms-4">
            <div className="infomation">
              <div className="img"></div>
              <div className="name">Wiwatakon pookpoon</div>
              <div className="tag">Front-end</div>
              <div className="role">
                สร้างเว็บตามที่ UI สร้าง โดยใช้ HTML, CSS, Vue
              </div>
              <Dropdown className="morebutton" align="end">
                <Dropdown.Toggle id="dropdown" as="span">
                  <img src={More} alt="More" />
                  <Dropdown.Menu style={{ width: "80px" }}>
                    <Dropdown.Item
                      eventKey="1"
                      // onClick={() => handleEditTag(elem.id)}
                    >
                      แก้ไข
                    </Dropdown.Item>
                    <Dropdown.Item eventKey="2" style={{ color: "red" }}>
                      ลบ
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown.Toggle>
              </Dropdown>
            </div>

            <div className="position">Member</div>
          </div>
          <CardNewMember />
        </Row>
      </Container>
    </Containerstyle>
  );
}

export default CardMember;
